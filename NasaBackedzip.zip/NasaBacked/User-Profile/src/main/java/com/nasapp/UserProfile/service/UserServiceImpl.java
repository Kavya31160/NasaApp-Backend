package com.nasapp.UserProfile.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
//import com.nasapp.UserProfile.Entity.AppConstant;
import com.nasapp.UserProfile.Entity.User;
import com.nasapp.UserProfile.exception.UserAlreadyExistsException;
import com.nasapp.UserProfile.exception.UserNotFoundException;
import com.nasapp.UserProfile.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	 KafkaTemplate<String, String> kafkaTemplate;

	 @Autowired
	 private Gson gson;

	@Autowired
	private UserRepo userRepo;
	
	private static final String TOPIC = "nasaApod";


	public UserServiceImpl(UserRepo userRepo) {
		this.userRepo = userRepo;
	}

	@Override
	public User saveUser(User user) {
		Optional<User> user1 = userRepo.findById(user.getId());
		if (user1.isPresent()) {
			throw new UserAlreadyExistsException("User Already Exists");
		}
		kafkaTemplate.send(TOPIC,gson.toJson(user));
		return userRepo.save(user);

	}

	@Override
	public User updateUser(User user) {
		Optional<User> user1 = userRepo.findById(user.getId());
		if (user1.isPresent()) {
			User tempuser = user1.get();
			tempuser.setFirstname(user.getFirstname());
			tempuser.setLastname(user.getLastname());
			tempuser.setEmailid(user.getEmailid());
			return userRepo.save(tempuser);
		} else {
			throw new UserNotFoundException("User not Found");
		}
	}

	@Override
	public User deleteUser(Long id) {
		Optional<User> user1 = userRepo.findById(id);
		if (user1.isPresent()) {
			userRepo.deleteById(id);
			return user1.get();
		} else {
			throw new UserNotFoundException("User not found");
		}

	}

	@Override
	public User findbyEmailid(String emailid) {
		return userRepo.findByEmailid(emailid);
	}

}
