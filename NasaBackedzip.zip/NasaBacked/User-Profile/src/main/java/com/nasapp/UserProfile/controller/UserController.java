package com.nasapp.UserProfile.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nasapp.UserProfile.Entity.User;
import com.nasapp.UserProfile.service.UserService;

@RestController
@RequestMapping("/user/v1")
public class UserController {
	
	   private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	
	@Autowired
	private UserService userservice;
	//http://localhost:8087/user/v1/saveUser
	//add user
	@PostMapping("/saveUser")
	public ResponseEntity<User> saveUser(@RequestBody User user){
		logger.info("Excuting Save User");

	 return new ResponseEntity<>(userservice.saveUser(user),HttpStatus.CREATED);


}
   //Update User
	//http://localhost:8087/swagger-ui/index.html
	//http://localhost:8087/user/v1/updateUser/2
	@PutMapping("/updateUser/{id}")
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable("id") long id){
		logger.info(" Updating User Info");

		return new ResponseEntity<>(userservice.updateUser(user),HttpStatus.OK);
	}
	//http://localhost:8083/user/v1/deleteUser/1
	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable("id")Long id){
		
		logger.info("Excuting Delete User");

		return new ResponseEntity<>(userservice.deleteUser(id),HttpStatus.OK);
	}
	
//http://localhost:8089/user/v1/ghana@gmail.com
	@GetMapping("/{emailid}")
	public ResponseEntity<User> findbyEmailid(@PathVariable String emailid){
		logger.info("Getting User Details");

		User user=userservice.findbyEmailid(emailid);
		if(user!=null)
		{
			return new ResponseEntity<>(user,HttpStatus.OK);
				}
		else {

			return new ResponseEntity<>(HttpStatus.NOT_FOUND); 
		}
	}
	

}
