package com.nasapp.UserProfile.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nasapp.UserProfile.Entity.User;
@Service
  public interface UserService {
       User saveUser(User user);
       User updateUser(User user);
       User deleteUser(Long id);
   	User findbyEmailid(String emailid);   
 
    
      
       
       
       
       
       
	}

	

