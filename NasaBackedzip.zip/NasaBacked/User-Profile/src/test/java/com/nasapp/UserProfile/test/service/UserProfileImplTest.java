package com.nasapp.UserProfile.test.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;

import com.google.gson.Gson;
import com.nasapp.UserProfile.Entity.User;
import com.nasapp.UserProfile.exception.UserAlreadyExistsException;
import com.nasapp.UserProfile.exception.UserNotFoundException;
import com.nasapp.UserProfile.repository.UserRepo;
import com.nasapp.UserProfile.service.UserServiceImpl;
 

@SpringBootTest
 class UserProfileImplTest {
 
    @Mock
    private UserRepo userRepo;
 
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
 
    @Mock
    private Gson gson;
 
    @InjectMocks
    private UserServiceImpl userService;
 
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

 
    @Test
    public void testSaveUser() {
        // Arrange
        User user = new User(/* provide user details here */);
 
        when(userRepo.findById(user.getId())).thenReturn(Optional.empty());
        when(gson.toJson(user)).thenReturn("jsonString");
 
        // Act
        User savedUser = userService.saveUser(user);
 
        // Assert
        assertNotNull(savedUser);
        assertEquals(user, savedUser);
 
        // Verify interactions
        verify(userRepo, times(1)).findById(user.getId());
        verify(kafkaTemplate, times(1)).send(eq("nasaApod"), eq("jsonString"));
        verify(userRepo, times(1)).save(user);
    }
 
    @Test(expected = UserAlreadyExistsException.class)
    public void testSaveUser_UserAlreadyExists() {
        // Arrange
        User user = new User(/* provide user details here */);
 
        when(userRepo.findById(user.getId())).thenReturn(Optional.of(user));
 
        // Act
        userService.saveUser(user);
 
        // Assert (Exception expected)
    }
 
    @Test
    public void testUpdateUser() {
        // Arrange
        User user = new User(/* provide user details here */);
 
        when(userRepo.findById(user.getId())).thenReturn(Optional.of(user));
        when(userRepo.save(any(User.class))).thenReturn(user);
 
        // Act
        User updatedUser = userService.updateUser(user);
 
        // Assert
        assertNotNull(updatedUser);
        assertEquals(user, updatedUser);
 
        // Verify interactions
        verify(userRepo, times(1)).findById(user.getId());
        verify(userRepo, times(1)).save(user);
    }
 
    @Test(expected = UserNotFoundException.class)
    public void testUpdateUser_UserNotFound() {
        // Arrange
        User user = new User(/* provide user details here */);
 
        when(userRepo.findById(user.getId())).thenReturn(Optional.empty());
 
        // Act
        userService.updateUser(user);
 
        // Assert (Exception expected)
    }
 
    @Test
    public void testDeleteUser() {
        // Arrange
        Long userId = 1L;
        User user = new User(/* provide user details here */);
 
        when(userRepo.findById(userId)).thenReturn(Optional.of(user));
 
        // Act
        User deletedUser = userService.deleteUser(userId);
 
        // Assert
        assertNotNull(deletedUser);
        assertEquals(user, deletedUser);
 
        // Verify interactions
        verify(userRepo, times(1)).findById(userId);
        verify(userRepo, times(1)).deleteById(userId);
    }
 
    @Test(expected = UserNotFoundException.class)
    public void testDeleteUser_UserNotFound() {
        // Arrange
        Long userId = 1L;
 
        when(userRepo.findById(userId)).thenReturn(Optional.empty());
 
        // Act
        userService.deleteUser(userId);
 
        // Assert (Exception expected)
    }
 
    @Test
    public void testFindbyEmailid() {
        // Arrange
        String emailId = "test@example.com";
        User user = new User(/* provide user details here */);
 
        when(userRepo.findByEmailid(emailId)).thenReturn(user);
 
        // Act
        User foundUser = userService.findbyEmailid(emailId);
 
        // Assert
        assertNotNull(foundUser);
        assertEquals(user, foundUser);
 
        // Verify interactions
        verify(userRepo, times(1)).findByEmailid(emailId);
    }
 
    @Test
    public void testFindbyEmailid_UserNotFound() {
        // Arrange
        String emailId = "nonexistent@example.com";
 
        when(userRepo.findByEmailid(emailId)).thenReturn(null);
 
        // Act
        User foundUser = userService.findbyEmailid(emailId);
 
        // Assert
        assertNull(foundUser);
 
        // Verify interactions
        verify(userRepo, times(1)).findByEmailid(emailId);
    }
}



