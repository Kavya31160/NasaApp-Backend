package com.nasaApp.wishlist.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nasaApp.wishlist.entity.Wishlist;
import com.nasaApp.wishlist.exception.UserNotFoundException;
import com.nasaApp.wishlist.repository.UserWishlistRepo;

@Service
public class UserWishListServiceImpl implements UserWishlistService {
	
	
	private final UserWishlistRepo userWishlistRepo;
	
	@Autowired
	public UserWishListServiceImpl(UserWishlistRepo userWishlistRepo) {
		this.userWishlistRepo = userWishlistRepo;
	}

	@Override
	public Wishlist addApod(Wishlist wishlist) {
		Optional<Wishlist> wishlistEntity=userWishlistRepo.findById(wishlist.getWishlistId());
		if(wishlistEntity.isPresent()) {
			 wishlistEntity.get().getApod().addAll(wishlist.getApod());
			 userWishlistRepo.save(wishlistEntity.get());
			 return wishlist;
		}else {
			return userWishlistRepo.save(wishlist);
			
		}
	
	}

	@Override
	public String removeApod(Long wishlistId, String apodId) {
		Optional<Wishlist> wishlistEntity = userWishlistRepo.findById(wishlistId);
		if (wishlistEntity.isPresent()) {
			wishlistEntity.get().getApod().removeIf(t -> t.getApodId().equalsIgnoreCase(apodId));
		} else {
			throw new UserNotFoundException("No wishlist present with id " + wishlistId);
		}
		userWishlistRepo.save(wishlistEntity.get());
		return "removed apod";
		
	}

	@Override
	public Wishlist findByWishlistId(Long wishlistId) {
	
		Optional<Wishlist> wishlist1 = userWishlistRepo.findById(wishlistId);
		if (wishlist1.isPresent()) {
			Wishlist userWishlist = wishlist1.get();
			return userWishlist;
		} else {
			throw new UserNotFoundException("Did not find Apod");
		}
	}
	}

	

