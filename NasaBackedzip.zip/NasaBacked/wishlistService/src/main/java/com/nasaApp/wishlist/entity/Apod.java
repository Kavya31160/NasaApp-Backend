package com.nasaApp.wishlist.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Apod {
	
	@Id
	private String apodId;
	private String title;
	private String url;


	
	public String getApodId() {
		return apodId;
	}
	public void setApodId(String apodId) {
		this.apodId = apodId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	public List<Wishlist> getWishlists() {
		return wishlists;
	}

	public void setWishlists(List<Wishlist> wishlists) {
		this.wishlists = wishlists;
	}

	@ManyToMany(mappedBy = "apod")
	@JsonIgnore
	private List<Wishlist> wishlists;
}
