package com.nasaApp.wishlist.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nasaApp.wishlist.entity.Wishlist;

public interface UserWishlistRepo extends JpaRepository<Wishlist, Long>{

}
