package com.nasaApp.wishlist.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nasaApp.wishlist.entity.Wishlist;
import com.nasaApp.wishlist.service.UserWishlistService;

@RestController
public class UserWishlistController {
		
	
	private final UserWishlistService wishlistservice;
	
	public UserWishlistController(UserWishlistService wishlistService) {
		super();
		this.wishlistservice=wishlistService;
	}

	@PostMapping("/addApod")
	public ResponseEntity<Wishlist> addApodk(@RequestBody Wishlist wishlist) {
		return new ResponseEntity<>(wishlistservice.addApod(wishlist), HttpStatus.CREATED);
	}

	@DeleteMapping("/removeApod")
	public ResponseEntity<String> removeApod(@RequestParam Long wishlistId, @RequestParam String trackId) {
		return new ResponseEntity<String>(wishlistservice.removeApod(wishlistId, trackId), HttpStatus.OK);

	}

	@GetMapping("/getApod/{wishlistId}")
	public ResponseEntity<Wishlist> getApod(@PathVariable Long wishlistId) {
		return new ResponseEntity<>(wishlistservice.findByWishlistId(wishlistId), HttpStatus.OK);
	}
	

}
