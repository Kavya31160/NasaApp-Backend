package com.nasaApp.wishlist.service;

import com.nasaApp.wishlist.entity.Wishlist;

public interface UserWishlistService {
	
	Wishlist addApod(Wishlist wishlist);	
	String  removeApod(Long id, String apodId);
	Wishlist findByWishlistId(Long id);
	

}
