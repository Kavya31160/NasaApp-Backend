package com.nasaappauth.AuthService.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nasaappauth.AuthService.model.UserInfo;


@Repository
public interface AuthRepo extends JpaRepository<UserInfo,String> {
	
	Optional<UserInfo> findByEmailidAndPassword(String emailid, String password);

}
