package com.nasaappauth.AuthService.service;

import org.springframework.stereotype.Service;

import com.nasaappauth.AuthService.model.UserInfo;

@Service
public interface AuthService {

			
			
	boolean login(String emailid,String password);
}
