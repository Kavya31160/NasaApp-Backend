package com.nasaappauth.AuthService.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.nasaappauth.AuthService.config.JwtTokenGenerator;
import com.nasaappauth.AuthService.exception.UserNotFoundException;
import com.nasaappauth.AuthService.model.UserInfo;
import com.nasaappauth.AuthService.service.AuthService;


@CrossOrigin
@RestController
public class AuthController {

	@Autowired
	private AuthService authService;

	@Autowired
	private Gson gson;

	private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody UserInfo userinfo) throws UserNotFoundException {

		if (userinfo.getEmailid() == null || userinfo.getPassword() == null) {
			logger.info("Validating User Credentials");

			throw new UserNotFoundException("email and password are null");
		}

		boolean result = authService.login(userinfo.getEmailid(), userinfo.getPassword());
		if (result == false) {
			throw new UserNotFoundException("Email / password mismatch");
		}
		if (result) {

			Map<String, String> mytoken = new JwtTokenGenerator().generateToken(userinfo);
			return new ResponseEntity<Map>(mytoken, HttpStatus.OK);
		} else
			return new ResponseEntity("Invalid user", HttpStatus.UNAUTHORIZED);
	}

}