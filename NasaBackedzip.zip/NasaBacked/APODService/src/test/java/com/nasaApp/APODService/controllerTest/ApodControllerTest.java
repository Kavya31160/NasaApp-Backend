package com.nasaApp.APODService.controllerTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.nasaApp.APODService.controller.ApodController;
import com.nasaApp.APODService.entity.ApodInfo;
import com.nasaApp.APODService.service.ApodService;

public class ApodControllerTest {
    @InjectMocks
    private ApodController apodController;
 
    @Mock
    private ApodService apodService;
 
    @Mock
    private Logger logger;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    @Test
    void getInfo_ReturnsApodInfo_Success() {
        // Arrange
        ApodInfo expectedInfo = new ApodInfo(/* Set your desired fields */);
        when(apodService.getApodInfo()).thenReturn(expectedInfo);
 
        // Act
        ResponseEntity<ApodInfo> responseEntity = apodController.getInfo();
 
        // Assert
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(expectedInfo, responseEntity.getBody());
        verify(logger).info("Getting Astro Information");
        verify(apodService).getApodInfo();
    }

}