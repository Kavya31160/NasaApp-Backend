package com.nasaApp.APODService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ApodServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApodServiceApplication.class, args);
	}

}
