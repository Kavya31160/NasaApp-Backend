package com.nasaApp.APODService.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nasaApp.APODService.entity.ApodInfo;
import com.nasaApp.APODService.service.ApodService;
@RestController
@RequestMapping("api/v1")
public class ApodController {
	
	@Autowired
	private ApodService apodService;
	
	   private static final Logger logger = LoggerFactory.getLogger(ApodController.class);

	
	public ApodController(ApodService mockedService) {
		// TODO Auto-generated constructor stub
	}


	@GetMapping("/getinfo")
	public ResponseEntity <ApodInfo> getInfo(){
		logger.info("Getting Astro Information");

		return new ResponseEntity<>(apodService.getApodInfo(),HttpStatus.OK);
	}
	
	

}
//http://localhost:8084/api/v1/getinfo