package com.nasaApp.APODService.service;

import com.nasaApp.APODService.entity.ApodInfo;

public interface ApodService {
	
	public ApodInfo getApodInfo();

}
