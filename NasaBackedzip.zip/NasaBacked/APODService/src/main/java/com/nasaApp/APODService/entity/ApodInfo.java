	package com.nasaApp.APODService.entity;

import lombok.Data;

//@Data
public class ApodInfo {

	private String service_version;
	private String date;
	private String explanation;
	private String hdurl;
	private String Media_type;

	private String title;

	private String url;
	
	public String getHdurl() {
		return hdurl;
	}
	public void setHdurl(String hdurl) {
		this.hdurl = hdurl;
	}
	
	//title
	public String getService_version() {
		return service_version;
	}
	public void setService_version(String service_version) {
		this.service_version = service_version;
	}
	public String getMedia_type() {
		return Media_type;
	}
	public void setMedia_type(String media_type) {
		Media_type = media_type;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getExplanation() {
		return explanation;
	}
	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}
	
}
