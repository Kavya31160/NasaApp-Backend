package com.nasaApp.APODService.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.nasaApp.APODService.entity.ApodInfo;

@Service
public class ApodServiceImpl implements ApodService {

	private static final Logger logger = LoggerFactory.getLogger(ApodServiceImpl.class);

	RestTemplate restTemplate = new RestTemplate();

	@Value("${url.nasa.apoddetails}")
	private String ApodUrl;

	@Override
	public ApodInfo getApodInfo() {
		logger.info("Executing get Music");

		ResponseEntity<ApodInfo> details = restTemplate.exchange(ApodUrl, HttpMethod.GET, getEntity(), ApodInfo.class);

		// System.out.println(ApodUrl);
		return details.getBody();
	}

	private HttpEntity getEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/json");
		return new HttpEntity<>(headers);

	}

}
